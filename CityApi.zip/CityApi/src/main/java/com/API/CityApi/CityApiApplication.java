package com.API.CityApi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CityApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(CityApiApplication.class, args);
	}

}
